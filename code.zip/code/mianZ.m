function mianZ
%%%%%Perform CVa on common datasets and CVd,CVm,CVa on extracted datasets
%%%%%cv=1 Perform CVa on common datasets
%%%%%cv=2 Perform CVd on extracted datasets
%%%%%cv=3 Perform CVm on extracted datasets
%%%%%cv=4 Perform CVa on extracted datasets
for cv=1:4
    main_cv(cv);
end

end

function main_cv(cv,D_M)
if cv==1
    M_D = preproce_dataset1();
    cv = 3;   
    flag = 1;
else
    M_D = preproce_dataset2();
    cv = cv-1;
    flag = 2;
end

%%%paramate
num = 0.1:0.2:0.9;  
beta = 2.^[-2:1:2];
lata1 = 2.^[0:1:4];
lata2 = 2.^[0:1:4];
%
canshu = [];
for i1=1:length(num)
    for i2 = 1:length(beta)
        for i3 = 1:length(lata1)   
            for i4 = 1:length(lata2)
                canshu = [canshu;[num(i1),beta(i2),lata1(i3),lata2(i4)]];
            end
        end
    end
end
%%The calculation results
seeds = [7771,4659,22,8367]; 
nF = 5;  
[N,NCW] = size(canshu);
result = zeros(N,NCW+1);

for i = 1:N
    i
    option = canshu(i,:);
    jieguo = cv_seed_KNMBP(D_M,seeds,cv,nF,option);   
    jieguo = [option,jieguo];
    result(i,:) = jieguo;     
end
%%%%%%%%% save the result
if cv==3 && flag == 1
    result_KDNRF_cva1 = result;   
    save result_KDNRF_cva1 result_KDNRF_cva1;  %cv for interaction based on dataset1 
elseif cv==1  && flag == 2
    result_KDNRF_cvd2 = result;
    save result_KDNRF_cvd2 result_KDNRF_cvd2;  %cv for disease based on dataset2 
elseif cv==2 && flag == 2
    result_KDNRF_cvm2 = result;
    save result_KDNRF_cvm2 result_KDNRF_cvm2;  %cv for miRNA based on dataset2 
elseif cv==3 && flag == 2
    result_KDNRF_cva2 = result;
    save result_KDNRF_cva2 result_KDNRF_cva2;  %cv for interaction based on dataset2
end
end

%%%%Calculate the predicted results under different seeds
function [result,AUC] = cv_seed_KNMBP(D_M,seeds,cv,nF,canshu)
Ns = length(seeds); 
tic
result = 0;
AUC = 0;
for i=1:Ns 
    cv_data = cross_validation(D_M.interaction,seeds(i),cv,nF);     
    [jieguo,AUC0] = fivecross_KNMBP(D_M,cv_data,seeds(i),canshu);
    result = result+jieguo;
    AUC = AUC+AUC0;  
end
result = result/Ns;
AUC = AUC/Ns;
toc
end

%%%%5-fold cross validation 
function [result,AUCxy] = five_data1_KNMBP(M_D,cv_data,canshu)
interaction = M_D.interaction;
dis_sim = M_D.dis_sim;
mir_sim = M_D.mir_sim;
nF = length(cv_data);
result = 0; 
AUCxy = 0;

for k=1:nF
%     fprintf('begin to implement the cross validation:round =%d/%d\n', k, nF);
    %%%%%%%%%%%%%%%%%%%%%%%%%  
    option.theta = 1.0;        
    option.max_iter=200;       
    train_set = interaction.*cv_data{k}{1};   
    scores = KNMBP_opt(train_set,dis_sim,mir_sim,canshu,option);
    predict_score = arrayfun(@(x,y)tx_opt(scores,x,y),cv_data{k}{2}(:,1),cv_data{k}{2}(:,2));
    [jieguo,AUCxy0] = model_evaluate(predict_score,cv_data{k}{3});
    result = result+ jieguo;
    AUCxy = AUCxy+AUCxy0;
end
result = result/nF;
AUCxy = AUCxy/nF;
end 

function c = tx_opt(A,b,c)
c = A(b,c);
end