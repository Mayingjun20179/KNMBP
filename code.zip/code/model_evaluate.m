%%%Refercence from Zhang W, Qu Q, Zhang Y, Wang W: 
%The linear neighborhood propagation method for predicting long non-coding RNA�Cprotein interactions.
%NEUROCOMPUTING 2018, 273:526-534
function [AUC,AUCxy] = model_evaluate(predict_score,real_label) %% evaulate our prediction 
predict_score = gpuArray(single(predict_score));
real_label = gpuArray(single(real_label));

predict_score = (predict_score-min(predict_score))/(max(predict_score)-min(predict_score)); 
threshold = (1:999)/1000;  

predict_matrix = bsxfun(@gt,predict_score(:),threshold);  
TP = sum(bsxfun(@and,predict_matrix,real_label(:)));
FP = sum(bsxfun(@and,predict_matrix,~real_label(:)));
FN = sum(bsxfun(@and,~predict_matrix,real_label(:)));
TN = sum(bsxfun(@and,~predict_matrix,~real_label(:)));

AUC_x = FP./(TN+FP);      
AUC_y = TP./(TP+FN);     
[AUC_x,ind] = sort(AUC_x);
AUC_y = AUC_y(ind);
AUC_x = [0,AUC_x];
AUC_y = [0,AUC_y];
AUC_x = [AUC_x,1];
AUC_y = [AUC_y,1];
AUCxy = [AUC_x(:),AUC_y(:)];
AUC = 0.5*AUC_x(1)*AUC_y(1)+sum((AUC_x(2:end)-AUC_x(1:end-1)).*(AUC_y(2:end)+AUC_y(1:end-1))/2);

end