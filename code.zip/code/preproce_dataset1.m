%%%%Extract the dataset1
function M_D = preproce_dataset1( )
str = load('knowndiseasemirnainteraction.txt');

nd = max(str(:,2));
nm = max(str(:,1));
[pp,~] = size(str);

FS = load('functional similarity matrix.txt');  %%miRNA
FSP = load('Functional similarity weighting matrix.txt');             
SS1 = load('disease semantic similarity matrix 1.txt');
SS2 = load('disease semantic similarity matrix 2.txt');
SS = (SS1+SS2)/2;
SSP = load('disease semantic similarity weighting matrix1.txt');
%interaction: adajency matrix for the disease-miRNA association network
%interaction(i,j)=1 means miRNA j is related to disease i
interaction = zeros(nd,nm);  
for i = 1:pp
    interaction(str(i,2),str(i,1)) = 1;
end
M_D.interaction = interaction; 
M_D.dis_sim = SS.*SSP;
M_D.mir_sim = FS.*FSP;


end



