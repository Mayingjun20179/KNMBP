function cv_data = cross_validation(intMat,seeds,cv,num)
%%%%Input
%intMat: The known interaction matrix
%cv: which cross-validation method.
%(cv=1:CV on disease;cv=2:CV on miRNA; cv=3: CV on interaction)
%num: The number of folds for cross validation
%%%%%Output
%cv_data{1}:The discriminant matrix, 
%the position of w(i,j)=1 represents the training set, and w(i,j)=0 represents the test set
%cv_data{2}: The index of testset
%cv_data{3}: The label of testset

Ns = length(seeds);
cv_data = cell(Ns,num);  
for i= 1:Ns
    [num_dis,num_miRNA] = size(intMat);   
    ndm = num_dis*num_miRNA;  
    rand('state',seeds(i))
    if cv<=2
        if cv == 1
            index = randperm(num_dis)';
        elseif cv == 2
            index = randperm(num_miRNA)';
        end
        step = floor(length(index)/num);   
        for j = 1:num   
            if j < num
                ii = index((j-1)*step+1:j*step);   
            else
                ii = index((j-1)*step+1:end);
            end
            if cv == 1
                test_data=[];                
                for k=1:length(ii)   
                    test_data = [test_data;[ii(k)*ones(num_miRNA,1),[1:num_miRNA]']];
                end
            elseif cv == 2
                test_data=[];               
                for k=1:length(ii)
                    test_data = [test_data;[[1:num_dis]',ii(k)*ones(num_dis,1)]];
                end
            end
            test_label = [];
            W = ones(size(intMat));
            for s=1:size(test_data,1)
                test_label = [test_label;intMat(test_data(s,1),test_data(s,2))];
                W(test_data(s,1),test_data(s,2)) = 0;
            end
            cv_data{i,j} = {W, test_data, test_label};
        end
    elseif cv == 3       
        ind1 = find(intMat==1); ind0 = find(intMat==0);
        ndg1 = length(ind1);   ndg0 = ndm - ndg1;
        index1 = ind1(randperm(ndg1));
        rand('state',seeds(i))
        index0 = ind0(randperm(ndg0));
        step1 = floor(length(index1)/num);   
        step0 = floor(length(index0)/num);   
        for j = 1:num   
            if j < num
                ii1 = index1((j-1)*step1+1:j*step1);
                ii0 = index0((j-1)*step0+1:j*step0);
            else
                ii1 = index1((j-1)*step1+1:end);
                ii0 = index0((j-1)*step0+1:end);
            end
            yy1 = ceil(ii1/num_dis);
            xx1 = mod(ii1,num_dis);        xx1(find(xx1==0)) = num_dis;
            yy0 = ceil(ii0/num_dis);       
            xx0 = mod(ii0,num_dis);        xx0(find(xx0==0)) = num_dis;
            test_data = [[xx0,yy0];[xx1,yy1]];  
            test_label = [];
            W = ones(size(intMat));
            for s=1:size(test_data,1)
                test_label = [test_label;intMat(test_data(s,1),test_data(s,2))];
                W(test_data(s,1),test_data(s,2)) = 0;
            end
            cv_data{i,j} = {W, test_data, test_label};
        end
    end
end
end


