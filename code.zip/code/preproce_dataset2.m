%%%%Extract the dataset2
function M_D = preproce_dataset2()
load DATASET2.mat;
%%%disease
dis = DATASET2.dis;
dis_name = dis.name(:,1);
dis_sim =  DCA_opt({dis.gene_sim,dis.go_sim});

%%%miRNA
mir = DATASET2.mir;
mir_name = mir.name(2:end,1);
mir_sim =  mir.sim;

%%%interaction
inter = DATASET2.interaction;
[~,indm] = cellfun(@(x)ismember(x,mir_name),inter(:,1));
[~,indd] = cellfun(@(x)ismember(x,dis_name),inter(:,2));
interaction = sparse(indm,indd,ones(size(inter,1),1));  %593*602
interaction = full(interaction);

M_D.interaction = interaction';
M_D.dis_sim = dis_sim;
M_D.mir_sim = mir_sim;



end



