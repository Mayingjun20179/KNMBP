function scores = KNMBP_opt(train_set,dis_sim,mir_sim,canshu,option)
[nd,nm] = size(train_set);
%****************    disease similartiy (KSNS_SdC��dis_sim)      
Y = xiuzheng_Y(train_set,dis_sim,mir_sim,15,0.8); 
%%%%% ****************** disease
num = canshu.num;   neighbor_num = floor(num*nd);
KSNS_SdC = KSNS2_opt(Y,neighbor_num,dis_sim,canshu);   
S_SNF_D = DCA_opt({dis_sim,KSNS_SdC});     S_SNF_D = matrix_normalize(S_SNF_D);  
%%% *************  miRNA 
neighbor_num = floor(num*nm);  
KSNS_SmC = KSNS2_opt(Y',neighbor_num,mir_sim,canshu);
S_SNF_M = DCA_opt({mir_sim,KSNS_SmC});  S_SNF_M = matrix_normalize(S_SNF_M);    

%Bidirectional propagation algorithm
option.beta1 = canshu.beta; option.beta2 = canshu.beta;
scores = LRMF1_score(train_set,S_SNF_D,S_SNF_M,option);  
end

function Y = xiuzheng_Y(Y0,dis_sim,dis_met,K,ar)  
ind_dis0 = find(sum(Y0')==0);   
ind_met0 = find(sum(Y0)==0);    
[Nd,Nm] = size(Y0);

%%
dis_sim(1:(Nd+1):end) = 0;      
dis_met(1:(Nm+1):end) = 0; 
dis_sim(ind_dis0,ind_dis0) = 0; 
dis_met(ind_met0,ind_met0) = 0;

[~,indd] = sort(dis_sim,2,'descend');
[~,indm] = sort(dis_met,1,'descend');
Yd = zeros(Nd,Nm);
ar = ar.^(0:K-1);
for i=1:Nd    
    near_ind = indd(i,1:K);
    Yd(i,:) = (ar.*dis_sim(i,near_ind))*Y0(near_ind,:)/sum(dis_sim(i,near_ind));
end
Ym = zeros(Nd,Nm);
for j=1:Nm    
    near_inm = indm(1:K,j);
    Ym(:,j) = Y0(:,near_inm)*(ar'.*dis_met(near_inm,j))/sum(dis_met(near_inm,j));
end 

Y = (Yd+Ym)/2;
Y = max(Y,Y0);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   KSNS
function S = KSNS2_opt(X,neighbor_num,sim,canshu)
neighbor_num = single(neighbor_num);
X = gpuArray(single(X));
sim = gpuArray(single(sim));
feature_matrix = X;
nearst_neighbor_matrix = KSNS_neighbors(sim,neighbor_num);
S = jisuanW_opt(feature_matrix,nearst_neighbor_matrix,canshu);
% class(S)
S =  gather(S);

end

function nearst_neighbor_matrix=KSNS_neighbors(sim,neighbor_num)
%%%%nearst_neighbor_matrix��  represent Neighbor matrix
  N = size(sim,1);
  D = sim+diag(inf*ones(1,N));
  [~, si]=sort(D,2,'ascend');
  nearst_neighbor_matrix=gpuArray.zeros(N,N);
  index=si(:,1:neighbor_num);
  for i=1:N
      nearst_neighbor_matrix(i,index(i,:))=1;     
  end
end

%The iterative process of this algorithm
function [W,objv] = jisuanW_opt(feature_matrix,nearst_neighbor_matrix,canshu)
lata1 = canshu.lata1;  lata2 = canshu.lata2;
X=feature_matrix';  % each column of X represents a sample, and each behavior is an indicator
[~,N] = size(X);    % N represents the number of samples
C = nearst_neighbor_matrix';
rand('state',1);
W = rand(N,N);
W = W- diag(diag(W));
W = W./repmat(sum(W),N,1);
G  =jisuan_Kel(X);
G(isnan(G))=0;
G = G/max(G(:));
WC1 = W'*G*W-2*W*G+G;
WC = sum(diag(WC1))/2;
wucha = WC + norm(W.*(1-C),'fro')^2*lata1/2 +  norm(W,'fro')^2*lata2/2;
objv = wucha;
jingdu = 0.0001;
error = jingdu*(1+lata1+lata2);   %Iteration error threshold
we = 1;      %Initial value of error
gen=1;
while  gen<100 && we>error
    %gen
    FZ = G+lata1*C.*W;
    FM = G*W+lata1*W+lata2*W;    
    W = FZ./(FM+eps).*W;  
    WC1 = W'*G*W-2*W*G+G;
    WC = sum(diag(WC1))/2;
    wucha = WC + norm(W.*(1-C),'fro')^2*lata1/2 +  norm(W,'fro')^2*lata2/2;    
    we = abs(wucha-objv(end));
    objv = [objv,wucha];
    gen = gen+1;
end
W=W'; 
W = matrix_normalize(W);
end

function W = matrix_normalize(W)
K = 10;
W(isnan(W))=0;
W(1:(size(W,1)+1):end)=0;
GW = gpuArray(single(W));
for round=1:K
    SW = sum(GW,2);
    ind = find(SW>0);
    SW(ind) = 1./sqrt(SW(ind));
    D1 = diag(SW);
    GW=D1*GW*D1;
end
W = gather(GW);
end

function K  =jisuan_Kel(X)
%X Columns represent samples, and rows represent features
X = X';
sA = (sum(X.^2, 2));
sB = (sum(X.^2, 2));
K = exp(bsxfun(@minus,bsxfun(@minus,2*X*X', sA), sB')/mean(sA));
end


function scores = LRMF1_score(intMat,S_D,S_M,option)

intMat = gpuArray(single(intMat));
S_D = gpuArray(single(S_D));
S_M = gpuArray(single(S_M));

DL = laplacian_matrix(S_D);
ML = laplacian_matrix(S_M);
scores = AGD_optimization(intMat,option,DL,ML);
scores =  gather(scores);
end

function F = AGD_optimization(intMat,option,DL,ML)

seed=2;
if length(seed)==0
    F = gpuArray.rand(size(intMat));
else
    rand('state',seed)
    F = rand(size(intMat));
    F = single(F);
end
dg_sum = zeros(size(F));
last_log = log_likelihood(intMat,F,DL,ML,option);   
objv  = [];
objv = [objv,last_log];
for t =  1:option.max_iter
    dg = deriv_opt(F,intMat,option,DL,ML);        
    dg_sum = dg_sum + dg.^2;       
    dg_sum = max(dg_sum,10^(-10));  
    vec_step_size = option.theta*ones(size(dg_sum))./ sqrt(dg_sum);  
    F = F + vec_step_size .* dg;   
    %%%%
    curr_log = log_likelihood(intMat,F,DL,ML,option);   
    delta_log = (curr_log-last_log)/abs(last_log);   
    if abs(delta_log) < 1e-5
        break;
    end
    last_log = curr_log; 
    objv = [objv,last_log];
end
end

function vec_deriv = deriv_opt(F,intMat,option,DL,ML)

vec_deriv = 2*(F - intMat) + option.beta1*DL*F + option.beta2*F*ML;
vec_deriv = -vec_deriv;
end

function loglik = log_likelihood(intMat,F,DL,ML,option)
loglik1 = norm(intMat - F,'fro');
loglik2 = trace(F'*DL*F)*option.beta1/2 + trace(F*ML*F')*option.beta2/2;
loglik =loglik1 + loglik2 ;

end



function L = laplacian_matrix(W)
L = eye(size(W,1))-W; 
end



%%%Reference from Wang S, Cho H, Zhai C, Berger B, Peng J: 
%%%Exploiting ontology graph for predicting sparsely annotated gene function
function S_S = DCA_opt(S)
d = 100;
Ns = length(S);              
option.maxiter =20;
option.reset_prob = 0.5;     
for i=1:Ns
    A = S{i};
    tA = run_diffusion(A, option);
    if i==1
        QA = tA;
    else
        QA = [QA,tA];
    end    
end

alpha = 1/size(QA,1);
QA = log(QA+alpha)-log(alpha);
QA = QA*QA';

QA = sparse(double(QA));
[U,S] = svds(QA,d);
LA = U;
S_F = LA*sqrt(sqrt(S));
S_S = abs(cos_opt(S_F));
end

function W = cos_opt(X)

W = X*X';
DX = sqrt(diag(W))*sqrt(diag(W))';
W = W./DX;

end

function [Q] = run_diffusion(A, option)
    n = size(A, 1); 
    renorm = @(M) bsxfun(@rdivide, M, sum(M));  
    A = A + diag(sum(A) == 0); % Add self-edges to isolated nodes����ĳһ�еĺ�Ϊ0������һ�жԽ���Ԫ�ر�Ϊ1)
    P = renorm(A); 
    reset = eye(n); 
    Q = reset;
    for i = 1:option.maxiter 
        Q_new = option.reset_prob * reset + (1 - option.reset_prob) * P * Q;
        delta = norm(Q - Q_new, 'fro');
%         fprintf('Iter %d. Frobenius norm: %f\n', i, delta);
        Q = Q_new;
        if delta < 1e-6
%             fprintf('Converged.\n');
            break
        end
    end    
    Q = bsxfun(@rdivide, Q, sum(Q));  
end





